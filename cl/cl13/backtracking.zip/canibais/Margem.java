package br.unb.cic.canibais;

import java.util.Arrays;

import br.unb.cic.algorithms.IState;

public class Margem implements IState<Margem>{
	private static final int POS_MISSIONARIO = 0;
	private static final int POS_CANIBAIS = 1;
	private static final int POS_BARCO = 2;
	
	public enum MargemID  { SUL, NORTE};
	
	int sul[] = new int[3];
	int norte[] = new int[3];

	public MargemID localizacaoBarco() {
		return sul[POS_BARCO] == 1 ? MargemID.SUL : MargemID.NORTE;
	}
	
	public int missionarios(MargemID margem) {
		if(margem.equals(MargemID.SUL)) {
			return sul[POS_MISSIONARIO];
		}
		return norte[POS_MISSIONARIO];
	}
	
	public int canibais(MargemID margem) {
		if(margem.equals(MargemID.SUL)) {
			return sul[POS_CANIBAIS];
		}
		return norte[POS_CANIBAIS];
	}
	
	public boolean equals(Object other) {
		if(other != null && other instanceof Margem) {
			Margem outraMargem = (Margem)other;
			return Arrays.equals(this.sul, outraMargem.sul) && Arrays.equals(this.norte, outraMargem.norte);
		}
		return false;
	}
	
	@Override
	public boolean test(Margem goal) {
		return this.equals(goal);
	}

	public String toString() {
		return "[" + sul[0] + "," + sul[1] + "," + sul[2] + "] --- " + "[" + norte[0] + "," + norte[1] + "," + norte[2] + "]"; 
	}
	@Override
	public boolean validState() {
		return !(((sul[POS_MISSIONARIO] > 0) && (sul[POS_CANIBAIS] > sul[POS_MISSIONARIO])) || 
			   ((norte[POS_MISSIONARIO] > 0) && (norte[POS_CANIBAIS] > norte[POS_MISSIONARIO]))); 
	}
}
