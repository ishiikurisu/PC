package br.unb.cic.canibais;

import java.util.ArrayList;
import java.util.List;

import br.unb.cic.algorithms.BackTracking;
import br.unb.cic.canibais.Margem.MargemID;

public class Missionarios extends BackTracking<Margem>{
	public Missionarios(Margem initialState, Margem finalState) {
		super(initialState, finalState);
	}

	@Override
	protected List<Margem> next(Margem currentState) {
		if(currentState.localizacaoBarco().equals(MargemID.SUL)) {
			return computarMovimentos(currentState, MargemID.SUL);
		}
		return computarMovimentos(currentState, MargemID.NORTE);
	}

	private List<Margem> computarMovimentos(Margem currentState, MargemID margem) {
		List<Margem> resultado = new ArrayList<Margem>();
		int missionarios = currentState.missionarios(margem);
		int canibais = currentState.canibais(margem);
		for(int i = missionarios; i >= 0; i--) {
			for(int j = canibais; j >= 0; j--) {
				if(i + j > 2 || i + j < 1) {
					continue;
				}
				Margem m = new Margem();
				if(margem.equals(MargemID.SUL)) {
					m.sul   = new int[]{missionarios -i, canibais -j, 0};
					m.norte = new int[]{3 - missionarios + i, 3 - canibais + j, 1};
				}
				else{
					m.norte   = new int[]{missionarios -i, canibais -j, 0};
					m.sul = new int[]{3 - missionarios + i, 3 - canibais + j, 1};
				}
				resultado.add(m);
			}
		}
		return resultado;
	}

}
