package br.unb.cic.canibais;

import java.util.List;

public class Main {

	public static void main(String args[]) {
		Margem start = new Margem();
		Margem end 	= new Margem();
		start.norte = new int[]{0,0,0};
		start.sul   = new int[]{3,3,1};
		
		end.norte = new int[]{3,3,1};
		end.sul = new int[]{0,0,0};
		
		Missionarios missionarios = new Missionarios(start, end);
		
		Margem f = missionarios.findSolution();
		
		List<Margem> solucao = missionarios.trace();
		System.out.println("Start: " + start);
		System.out.println("End: " + end + "\n \n");
		
		
		if(f != null) {
			System.out.println("Found a solution with " + solucao.size() + " movements.");
		
			for(int i = solucao.size() -1; i >= 0; i--) {
				System.out.println(solucao.get(i));
			}
		}
		else{
			System.out.println("solution not found");
		}
	}
}
