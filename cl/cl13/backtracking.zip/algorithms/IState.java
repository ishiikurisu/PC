package br.unb.cic.algorithms;

public interface IState<T> {
	public boolean validState();
	public boolean test(T goal);
}
