package br.unb.cic.algorithms;

import java.util.ArrayList;
import java.util.List;

/**
 * This is an abstract, generic class that implements 
 * the strategy of solving problems using backtracking, a
 * kind of brute force approach that works fine when the 
 * size of the problem is small. We can understand backtracking as 
 * a depth first search on a decision tree. 
 * 
 * @author rbonifacio
 *
 * @param <T> any type that implements IState, an interface 
 * with methods for generating futures steps in the decision 
 * tree and for checking whether a state is valid or 
 * not (according to the problem domain).
 */
public abstract class BackTracking<T extends IState<T>> {
	private T initialState;
	private T finalState;
	
	private List<T> trace; 
	
	private List<T> visitedStates;
	
	public BackTracking(T initialState, T finalState) {
		this.initialState = initialState;
		this.finalState = finalState;
		visitedStates = new ArrayList<T>();
		visitedStates.add(initialState);
	
		trace = new ArrayList<T>();
	}
	
	/**
	 * Solve the problem through a backtracking 
	 * approach. 
	 * 
	 * @return a solution to the problem as a state 
	 * that satisfies the condition of the final 
	 * state. Returns <i>null</i> in the case that a 
	 * solution could not be found. 
	 */
	public T findSolution() {
		return findSolution(initialState);
	}
	
	/*
	 * That is an interesting illustration of 
	 * a template method. This algorithm is almost 
	 * complete, though it calls the abstract 
	 * method next().
	 */
	private T findSolution(T currentState) {
		if(currentState.test(finalState)) {
			return currentState;
		}
		for(T state: next(currentState)) {
			//here we prune both invalid and visited states.
			if((!state.validState()) || (visitedStates.contains(state))) {
				continue;
			}
			visitedStates.add(state);
			T s = findSolution(state);
			if(s != null) {
				trace.add(state);
				return s;
			}
		}
		return null;
	}
	
	/**
	 * @return the trace with the intermediate states 
	 * in the path from the startState and the finalState.
	 */
	public List<T> trace() {
		return trace;
	}
	
	//from the current state, we should be able to 
	//derive a list of possible future states. This is an 
	//abstract method, mainly because it depends on the 
	//problem.
	protected abstract List<T> next(T currentState);
	
	
	
}
